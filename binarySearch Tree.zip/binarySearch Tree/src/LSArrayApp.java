import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;


/**
 * @author ritshidze
 *
 */
public class LSArrayApp {

	public static String time = null;
	public static String area = null;
	public static String date = null;
	public static String stage = null;

	public static  Scanner f = null;


	/**
	 * opens and read the file
	 * @throws FileNotFoundException   when the file is not found
	 */
	public static void readFile(String fileName) throws FileNotFoundException
	{
		f = new Scanner(new File(fileName));
	}

	
	
	
	/**
	 * use the loop to take all lines from the file as strings
	 * split the lines using character (_)
	 * get   time stage ,time, and area
	 * and print area only
	 * 
	 */
	public static void printAllAreas()
	{
		for (int i = 0 ; i < 2976 ; i++)
		{  
			String word = f.nextLine();

			String[] words = word.split("_");

			String timeArea = words[2];

			date = words[1].trim();
			stage = words[0].trim();
			time = timeArea.substring(0,2).trim();
			area = timeArea.substring(3).trim();
			System.out.println(area);

		}
	}
	
	
	/**
	 * @param s for stage
	 * @param d for date
	 * @param startTime for loadshedding
	 * use loop to take all lines from file and split them
	 * then print area of the matching date stage and startTime given by user
	 * and print "area not found" if the is no match
	 * 
	 */
	@SuppressWarnings("unused")
	public static void prinAreas(String s , String d , String startTime)
	{   
		for (int i = 0 ; i < 2976 ; i++)
		{  
			String word = f.nextLine();

			String[] words = word.split("_");

			String timeArea = words[2];

			date = words[1].trim();
			stage = words[0].trim();
			time = timeArea.substring(0,2).trim();
			area = timeArea.substring(3).trim();

			if (date.trim().equals(d.trim()) && stage.trim().contentEquals(s.trim()) && time.trim().equals(startTime.trim())) {
				System.out.println(area);
				System.exit(0);
			}		
		}
		System.out.println("Areas not found");

	}
	
	/**
	 * this method write all the output into the file named output1.txt
	 */
	
	public static int opcount= 0;
	public void opCounter(){
		  
        //Create the file
        try{
        File file = new File("Countfile.txt");
        if (file.createNewFile())
        {
             //Write Content
             FileWriter writer = new FileWriter(file);
             writer.write("There are "+opcount+" Comparison Operations.");
             writer.close();

            } else {
                System.out.println("File already exists.");
            }
            
        }catch(Exception e){
            System.out.println("Error occured");
        }
    }
	
    //close the loadshedding file
	public static void close() {
		f.close();
	}


	/**
	 * @param args is the default argument for main
	 * print matching area or area not found if user provide parameters
	 * print all areas if user dont provide parameters
	 * 
	 * 
	 */
	@SuppressWarnings({ "resource" }) 
	public static void main(String [] args) {

		try {
			readFile("Load_Shedding_All_Areas_Schedule_and_Map.clean.final.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Scanner input = new Scanner(System.in);

		String userInput = input.nextLine();
		String[] inputList = userInput.split(" ");

		if (userInput.isEmpty()) { 
			printAllAreas();
		}
		else{
			String stg = inputList[0].trim();
			String day = inputList[1].trim();
			String startTime = inputList[2].trim();

			prinAreas(stg, day, startTime);
		}
//class close method to close the file
		close();
	}

}
